<!DOCTYPE html>
<html lang="eng">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page 1</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
<body>
<div class='container'>
<?php
require("db.php");
$mysqli = new mysqli(SERVER, USER, PASSWORD, DB);

$sql = "SELECT COALESCE(ccd.Description, 'UNSPECIFIED') AS Description, COUNT(*) AS total_reports
FROM incident i
JOIN crime_code cc ON i.DR_NO = cc.DR_NO
JOIN crime_code_description ccd ON cc.Crm_Cd = ccd.Crm_Cd
GROUP BY Description
ORDER BY total_reports DESC
LIMIT 5";

$result = $mysqli->query($sql);

echo "<h1 class='text-center mt-4 mb-4'>LAPD Most Frequent Crimes</h1>";
echo "<table class='table table-striped'>
<tr>
<th>Crime Description</th>
<th>Total Reports</th>
</tr>";
foreach($result as $row){
    echo "<tr>
    <td>".$row['Description']."</td>
    <td>".$row['total_reports']."</td>
    </tr>";
}
echo "</table>"
?>
</div>
</body>
</html>