<!DOCTYPE html>
<html lang="eng">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page 6</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
<body>
<div class='container'>
<?php
require("db.php");
$mysqli = new mysqli(SERVER, USER, PASSWORD, DB);

$sql = "SELECT MONTHNAME(i.DATE_OCC) AS Month, COUNT(*) AS Total_Incidents
FROM incident i
JOIN weapon w ON i.Weapon_Used_Cd = w.Weapon_Used_Cd
WHERE i.Vict_Sex = 'F'
  AND (
       w.Weapon_Desc LIKE '%SEMI-AUTOMATIC PISTOL%' OR
       w.Weapon_Desc LIKE '%SIMULATED GUN%' OR
       w.Weapon_Desc LIKE '%OTHER FIREARM%' OR
       w.Weapon_Desc LIKE '%UNKNOWN FIREARM%' OR
       w.Weapon_Desc LIKE '%AIR PISTOL/REVOLVER/RIFLE/BB GUN%' OR
       w.Weapon_Desc LIKE '%RIFLE%' OR
       w.Weapon_Desc LIKE '%REVOLVER%'
  )
  AND YEAR(i.DATE_OCC) = 2020
GROUP BY MONTH(i.DATE_OCC), MONTHNAME(i.DATE_OCC)
ORDER BY MONTH(i.DATE_OCC)";

$result = $mysqli->query($sql);

echo "<h1 class='text-center mt-4 mb-4'>LAPD Firearm Related Incidents Involving Female Victims </h1>";
echo "<table class='table table-striped'>
<tr>
<th>Month</th>
<th>Total Incidents</th>
</tr>";
foreach($result as $row){
    echo "<tr>
    <td>".$row['Month']."</td>
    <td>".$row['Total_Incidents']."</td>
    </tr>";
}
echo "</table>"
?>
</div>
</body>
</html>