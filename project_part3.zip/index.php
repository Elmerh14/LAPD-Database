<!DOCTYPE html>
<html lang="eng">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Index</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
<body>
<div class='container'>
<?php
require("db.php");
$mysqli = new mysqli(SERVER, USER, PASSWORD, DB);


echo "<h1 class='text-center mt-4'>LPD Crime Reports Landing Page </h1>";

echo '
<div class="d-flex flex-wrap justify-content-center gap-4 mt-4">
    <a href="https://csci3287.cse.ucdenver.edu/~hernaelm/project/page1.php" class="btn btn-primary" target="_blank">Page 1</a>
    <a href="https://csci3287.cse.ucdenver.edu/~hernaelm/project/page2.php" class="btn btn-primary" target="_blank">Page 2</a>
    <a href="https://csci3287.cse.ucdenver.edu/~hernaelm/project/page3.php" class="btn btn-primary" target="_blank">Page 3</a>
    <a href="https://csci3287.cse.ucdenver.edu/~hernaelm/project/page4.php" class="btn btn-primary" target="_blank">Page 4</a>
    <a href="https://csci3287.cse.ucdenver.edu/~hernaelm/project/page5.php" class="btn btn-primary" target="_blank">Page 5</a>
    <a href="https://csci3287.cse.ucdenver.edu/~hernaelm/project/page6.php" class="btn btn-primary" target="_blank">Page 6</a>
</div>';


?>
</div>
</body>
</html>