<!DOCTYPE html>
<html lang="eng">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page 2</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
<body>
<div class='container'>
<?php
require("db.php");
$mysqli = new mysqli(SERVER, USER, PASSWORD, DB);

$sql = "SELECT a.Area, a.Area_Name, COUNT(i.DR_NO) AS Total_Incidents
FROM area a
LEFT JOIN rpt_no r ON a.Area = r.Area
LEFT JOIN incident i ON r.Rpt_Dist_No = i.Rpt_Dist_No
GROUP BY a.Area, a.Area_Name
ORDER BY Total_Incidents DESC";

$result = $mysqli->query($sql);

echo "<h1 class='text-center mt-4 mb-4'>Number of Incidents in Each Area</h1>";
echo "<table class='table table-striped'>
<tr>
<th>Area Number</th>
<th>Area Name</th>
<th>Total Incidents</th>
</tr>";
foreach($result as $row){
    echo "<tr>
    <td>".$row['Area']."</td>
    <td>".$row['Area_Name']."</td>
    <td>".$row['Total_Incidents']."</td>
    </tr>";
}
echo "</table>"
?>
</div>
</body>
</html>