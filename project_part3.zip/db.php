<?php
define("SERVER", "localhost");
define("USER", "hernaelm");
define("PASSWORD", "55ilW/2OyDs0");
define("DB", "hernaelm_PROJECT");
?>