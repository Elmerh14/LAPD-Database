<!DOCTYPE html>
<html lang="eng">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page 5</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
<body>
<div class='container'>
<?php
require("db.php");
$mysqli = new mysqli(SERVER, USER, PASSWORD, DB);

$sql = "SELECT i.DR_NO, i.DATE_OCC, w.Weapon_Desc
FROM incident i
JOIN weapon w ON i.Weapon_Used_Cd = w.Weapon_Used_Cd
WHERE w.Weapon_Desc LIKE '%SEMI-AUTOMATIC PISTOL%'
   OR w.Weapon_Desc LIKE '%SIMULATED GUN%'
   OR w.Weapon_Desc LIKE '%OTHER FIREARM%'
   OR w.Weapon_Desc LIKE '%UNKNOWN FIREARM%'
   OR w.Weapon_Desc LIKE '%AIR PISTOL/REVOLVER/RIFLE/BB GUN%'
   OR w.Weapon_Desc LIKE '%RIFLE%'
   OR w.Weapon_Desc LIKE '%REVOLVER%'";

$result = $mysqli->query($sql);

echo "<h1 class='text-center mt-4 mb-4'>LAPD Firearm Related Incidents</h1>";
echo "<table class='table table-striped'>
<tr>
<th>District Incident Report Number</th>
<th>Date Incident Occured</th>
<th>Weapon Description</th>
</tr>";
foreach($result as $row){
    echo "<tr>
    <td>".$row['DR_NO']."</td>
    <td>".$row['DATE_OCC']."</td>
    <td>".$row['Weapon_Desc']."</td>
    </tr>";
}
echo "</table>"
?>
</div>
</body>
</html>