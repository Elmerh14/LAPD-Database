<!DOCTYPE html>
<html lang="eng">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page 4</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
<body>
<div class='container'>
<?php
require("db.php");
$mysqli = new mysqli(SERVER, USER, PASSWORD, DB);

$sql = "SELECT r.Rpt_Dist_No AS District, a.Area_Name AS Area, MONTHNAME(i.DATE_OCC) AS Month, COUNT(*) AS Total_Incidents
FROM incident i
JOIN rpt_no r ON i.Rpt_Dist_No = r.Rpt_Dist_No
JOIN area a ON r.Area = a.Area
WHERE YEAR(i.DATE_OCC) = 2020
GROUP BY r.Rpt_Dist_No, a.Area_Name, MONTH(i.DATE_OCC), MONTHNAME(i.DATE_OCC)
ORDER BY r.Rpt_Dist_No, MONTH(i.DATE_OCC)";

$result = $mysqli->query($sql);

echo "<h1 class='text-center mt-4 mb-4'>Monthly Crime Counts per Reporting District</h1>";
echo "<table class='table table-striped'>
<tr>
<th>District Number</th>
<th>Associated Area Name</th>
<th>Month</th>
<th>Total Incidents</th>
</tr>";
foreach($result as $row){
    echo "<tr>
    <td>".$row['District']."</td>
    <td>".$row['Area']."</td>
    <td>".$row['Month']."</td>
    <td>".$row['Total_Incidents']."</td>
    </tr>";
}
echo "</table>"
?>
</div>
</body>
</html>